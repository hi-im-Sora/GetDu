
#' Identifica o DU do dia trabalhado, e o mesmo do mês anterior
#'
#' Funcao que retorna as principais variaveis de data dentro de uma dataframe
#' @param manual Data que vai retornar na tabela.
#' @return Por padrao, sera sempre o Sys Date-y
#' @examples
#' get_du(manual = '2022-12-24')
#'
#' @param bender Deixar como T caso esteja utilizando a variavel "datas" carregando a funcao bender do pacote baymax.
#' @return None
#'
#' @param sab Caso seja TRUE, define que o sabado tera o mesmo dia util da sexta-feira. Como FALSE, sera o mesmo da proxima segunda-feira.
#' @return None
#'
#' @param fechamento Caso seja TRUE, define que caso a data trabalhada seja a ultima do mes atual, o dia do mes anterior sera tambem o ultimo do mes anterior, mesmo que o DU seja diferente.
#' @return None
#'
#' @param corpus_christi CASO SEJA T, nao ira considerar o feriado de Corpus Christi como dia util.
#' @return None
#'
#' @param y Define a quantidade de dias a ser subtraido do manual. Por padrao sempre sera zero.
#' @return None
#' @examples
#' get_du(manual = '2022-12-24', y=3). A data retornada sera '2022-12-21'
#'
#' @export

get_du = function(manual = Sys.Date(), bender = F, sab = F, fechamento = T, corpus_christi = F, y=0) {
  library('dplyr')

  hoje = as.Date('2021-01-01')

  dates = data.frame(hoje)

  ###PEGANDO AT? 2031
  TabelaDeDatas = function() {

    hoje = as.Date('2021-01-01')

    dates = data.frame(hoje)

    for (x in 1:3652) {
      hoje = hoje+1

      temp = data.frame(hoje)
      dates = rbind(dates,temp)
    }

    dates = dplyr::mutate(dates, semana = weekdays(hoje),
                          indice = ifelse(hoje == '2021-01-01',1,
                                          ifelse(substr(lag(hoje),6,7) != substr(hoje,6,7),1,0)),
                          datinha = substr(hoje,6,10))

    sexta = 'Sexta feira Santa'
    feriados = data.frame(feriados = c('01-01','04-21','05-01','09-07','10-12','11-02','11-15','12-25','2021-04-02','2022-04-15','2023-04-07','2024-03-29','2025-04-18','2026-04-03','2027-03-26','2028-04-14','2029-03-30','2030-04-19'),
                          nome_feriado = c('Ano novo', 'Tiradentes', 'Dia do trabalho', 'Dia da Independencia', 'Dia de Nossa Senhora Aparecida', 'Dia de Finados','Proclamacao da Republica','Natal',sexta,sexta,sexta,sexta,sexta,sexta,sexta,sexta,sexta,sexta),
                          valid = '1')

    if(corpus_christi == T) {
      cc = 'Corpus Christi'
      CC = data.frame(feriados = c('2021-06-03','2022-06-16','2023-06-08','2024-05-30','2025-06-19','2026-06-04','2027-05-27','2028-06-15','2029-05-31','2030-06-20'),
                      nome_feriado = c(cc,cc,cc,cc,cc,cc,cc,cc,cc,cc),
                      valid = '1')
      feriados = rbind(feriados,CC)
    }

    dates = dplyr::left_join(dates,feriados, c('datinha' = 'feriados')) %>%
      dplyr::mutate(valid = ifelse(is.na(valid),0,valid))

    zero = dplyr::filter(dates,valid=='0') %>%
      dplyr::mutate(valid = NULL,
                    hoje = as.character(hoje)) %>%
      dplyr::left_join(feriados, c('hoje' = 'feriados')) %>%
      dplyr::mutate(valid = ifelse(is.na(valid),0,valid),
                    hoje = as.Date(hoje)) %>%
      dplyr::select(hoje, valid2 = valid)

    dates = dplyr::left_join(dates,zero, 'hoje') %>%
      dplyr::mutate(valid2 = ifelse(is.na(valid2),0,valid2),
                    VALID = ifelse(valid == 1,1,
                                   ifelse(valid2 == 1,1,
                                          ifelse(semana %in% c('sábado','domingo'),1,0))),
                    valid = NULL,
                    valid2 =NULL)

    ### loop para criar os DUs com validacoes mt insanas feitas em momentos de inspiracao
    for (x in 1:nrow(dates)) {
      y = x-1
      if(dates$indice[x] != 1) {
        if(dates$semana[x] != 'sábado' & dates$semana[x] != 'domingo') {
          if(dates$indice[y] == 1 & dates$VALID[y] == 1 & substr(dates$hoje[x-2],9,10) != '01') {
            dates$indice[x] = dates$indice[y]
          } else if(dates$semana[x] == 'segunda-feira' & dates$indice[x-2] != dates$indice[x-3]) {
            dates$indice[x] = dates$indice[y]
          } else if(dates$VALID[x] != 1) {
            dates$indice[x] = dates$indice[y]+1
          } else {
            dates$indice[x] = dates$indice[y]
          }
        } else {
          if(dates$semana[x] == 'sábado' & dates$VALID[y] == 0) {
            dates$indice[x] = dates$indice[y]+1
          } else {
            dates$indice[x] = dates$indice[y]
          }
        }
      }
    }


    if(sab == T) {
      dates = dplyr::mutate(dates, indice = ifelse(semana == 'sábado' & lag(indice) != indice & substr(hoje,9,10) != '01',lag(indice),indice))
    } else {
      dates = dplyr::mutate(dates, indice = ifelse(semana == 'sábado' & substr(lead(hoje, n=2),9,10) == '01',lag(indice),
                                                   ifelse(semana == 'sábado' & substr(lead(hoje),9,10) == '01',lag(indice),indice)))
    }

    dates = dplyr::mutate(dates, indice = ifelse(semana == 'domingo',lag(indice),indice),
                          nome_feriado = ifelse(is.na(nome_feriado),'-',nome_feriado))

    return(dates)
  }

  dates = TabelaDeDatas()

  ### VALID SE O CODIGO EST? NO PADRAO BENDER
  if(bender == F) {
    hoje_real = as.Date(manual)-y
    if(weekdays(hoje_real) == 'domingo') {
      hoje_real = hoje_real-1
    }
  }else {
    hoje_real = as.Date(datas$fim)
  }

  ### FECHAMENTO ???
  valid_fechamento = dplyr::mutate(dates, VALID2 = ifelse(substr(lead(hoje),9,10) == '01',1,
                                                          ifelse(substr(lead(hoje, n=2),9,10) == '01' & lead(VALID) == 1,1,
                                                                 ifelse(substr(lead(hoje, n=3),9,10) == '01' & lead(VALID, n=2) == 1 & lead(VALID) == 1,1,0)))) %>%
    dplyr::filter(hoje == hoje_real,
                  VALID2 == 1)

  ### VARIAVEIS CRIADAS
  data_hoje = dplyr::filter(dates, hoje == hoje_real)$hoje
  du_atual = dplyr::filter(dates, hoje == hoje_real)$indice
  dia = substr(data_hoje, 9,10)
  mes = substr(data_hoje, 6,7)
  mes_ant = ifelse(mes == '01','12',
                   ifelse(as.numeric(mes)-1 <=9,paste0('0',as.numeric(mes)-1),as.character(as.numeric(mes)-1)))
  ano = substr(data_hoje,1,4)
  ano_ant = ifelse(mes == '01',as.character(as.numeric(ano)-1),ano)

  ### VALIDANDO SE O DU ATUAL E MAIOR QUE O ULTIMO DU DO MES ANTERIOR
  max_ant = max(dplyr::filter(dates, substr(hoje,1,7) == paste0(ano_ant,'-',mes_ant))$indice)
  valid_du = ifelse(du_atual > max_ant,T,F)


  if(nrow(valid_fechamento)>=1 & fechamento == T | valid_du == T) {
    data_ant  = dplyr::filter(dates, as.character(lead(hoje)) == paste0(ano,'-',mes,'-01'))$hoje
  } else {
    data_ant = dplyr::filter(dates, substr(hoje,1,7) == paste0(ano_ant,'-',mes_ant),
                             indice == du_atual,
                             VALID == 0)$hoje
  }

  dia_ant = substr(data_ant,9,10)

  df = data.frame(data_hoje,du_atual,dia,dia_ant,mes,mes_ant,ano,ano_ant,data_ant)

  if(bender == T) {
    df = cbind(datas,df)
  }

  return(df)

}
